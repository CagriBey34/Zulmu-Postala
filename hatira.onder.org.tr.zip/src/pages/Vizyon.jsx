import React from 'react'

const Vizyon = () => {
  return (
    <div className='desc-page-container'>
    <h1 className='desc-page-title'>VİZYON</h1>
    <div className='desc-page-section'>
    <p>
    Medeniyetimizden aldığımız ilham ile çağın ötesinde bir ufka sahip; dünya üzerindeki haksızlık ve adaletsizlik karşısında susmayan, gelenekten aldığı güçle geleceğe yürüyen önderler yetiştirmek.
    </p>
    </div>
  </div>
  )
}

export default Vizyon